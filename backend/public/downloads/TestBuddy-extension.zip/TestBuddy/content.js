(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=((n,r,a)=>(a=n==null?{}:e(i(n)),s(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n)))(o(((e,t)=>{(function(n,r){if(typeof define==`function`&&define.amd)define(`webextension-polyfill`,[`module`],r);else if(e!==void 0)r(t);else{var i={exports:{}};r(i),n.browser=i.exports}})(typeof globalThis<`u`?globalThis:typeof self<`u`?self:e,function(e){"use strict";if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw Error(`This script should only be loaded in a browser extension.`);globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id?e.exports=globalThis.browser:e.exports=(e=>{let t={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(t).length===0)throw Error(`api-metadata.json has not been included in browser-polyfill`);class n extends WeakMap{constructor(e,t=void 0){super(t),this.createItem=e}get(e){return this.has(e)||this.set(e,this.createItem(e)),super.get(e)}}let r=e=>e&&typeof e==`object`&&typeof e.then==`function`,i=(t,n)=>(...r)=>{e.runtime.lastError?t.reject(Error(e.runtime.lastError.message)):n.singleCallbackArg||r.length<=1&&n.singleCallbackArg!==!1?t.resolve(r[0]):t.resolve(r)},a=e=>e==1?`argument`:`arguments`,o=(e,t)=>function(n,...r){if(r.length<t.minArgs)throw Error(`Expected at least ${t.minArgs} ${a(t.minArgs)} for ${e}(), got ${r.length}`);if(r.length>t.maxArgs)throw Error(`Expected at most ${t.maxArgs} ${a(t.maxArgs)} for ${e}(), got ${r.length}`);return new Promise((a,o)=>{if(t.fallbackToNoCallback)try{n[e](...r,i({resolve:a,reject:o},t))}catch(i){console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,i),n[e](...r),t.fallbackToNoCallback=!1,t.noCallback=!0,a()}else t.noCallback?(n[e](...r),a()):n[e](...r,i({resolve:a,reject:o},t))})},s=(e,t,n)=>new Proxy(t,{apply(t,r,i){return n.call(r,e,...i)}}),c=Function.call.bind(Object.prototype.hasOwnProperty),l=(e,t={},n={})=>{let r=Object.create(null),i={has(t,n){return n in e||n in r},get(i,a,u){if(a in r)return r[a];if(!(a in e))return;let d=e[a];if(typeof d==`function`)if(typeof t[a]==`function`)d=s(e,e[a],t[a]);else if(c(n,a)){let t=o(a,n[a]);d=s(e,e[a],t)}else d=d.bind(e);else if(typeof d==`object`&&d&&(c(t,a)||c(n,a)))d=l(d,t[a],n[a]);else if(c(n,`*`))d=l(d,t[a],n[`*`]);else return Object.defineProperty(r,a,{configurable:!0,enumerable:!0,get(){return e[a]},set(t){e[a]=t}}),d;return r[a]=d,d},set(t,n,i,a){return n in r?r[n]=i:e[n]=i,!0},defineProperty(e,t,n){return Reflect.defineProperty(r,t,n)},deleteProperty(e,t){return Reflect.deleteProperty(r,t)}},a=Object.create(e);return new Proxy(a,i)},u=e=>({addListener(t,n,...r){t.addListener(e.get(n),...r)},hasListener(t,n){return t.hasListener(e.get(n))},removeListener(t,n){t.removeListener(e.get(n))}}),d=new n(e=>typeof e==`function`?function(t){e(l(t,{},{getContent:{minArgs:0,maxArgs:0}}))}:e),f=new n(e=>typeof e==`function`?function(t,n,i){let a=!1,o,s=new Promise(e=>{o=function(t){a=!0,e(t)}}),c;try{c=e(t,n,o)}catch(e){c=Promise.reject(e)}let l=c!==!0&&r(c);return c!==!0&&!l&&!a?!1:((e=>{e.then(e=>{i(e)},e=>{let t;t=e&&(e instanceof Error||typeof e.message==`string`)?e.message:`An unexpected error occurred`,i({__mozWebExtensionPolyfillReject__:!0,message:t})}).catch(e=>{console.error(`Failed to send onMessage rejected reply`,e)})})(l?c:s),!0)}:e),p=({reject:t,resolve:n},r)=>{e.runtime.lastError?e.runtime.lastError.message===`The message port closed before a response was received.`?n():t(Error(e.runtime.lastError.message)):r&&r.__mozWebExtensionPolyfillReject__?t(Error(r.message)):n(r)},m=(e,t,n,...r)=>{if(r.length<t.minArgs)throw Error(`Expected at least ${t.minArgs} ${a(t.minArgs)} for ${e}(), got ${r.length}`);if(r.length>t.maxArgs)throw Error(`Expected at most ${t.maxArgs} ${a(t.maxArgs)} for ${e}(), got ${r.length}`);return new Promise((e,t)=>{let i=p.bind(null,{resolve:e,reject:t});r.push(i),n.sendMessage(...r)})},h={devtools:{network:{onRequestFinished:u(d)}},runtime:{onMessage:u(f),onMessageExternal:u(f),sendMessage:m.bind(null,`sendMessage`,{minArgs:1,maxArgs:3})},tabs:{sendMessage:m.bind(null,`sendMessage`,{minArgs:2,maxArgs:3})}},g={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return t.privacy={network:{"*":g},services:{"*":g},websites:{"*":g}},l(e,h,t)})(chrome)})}))(),1);function l(e){return`**${e.replace(/\*\*/g,``)}**`}function u(e){return d(e).replace(/\*\*(.+?)\*\*/g,`<strong>$1</strong>`)}function d(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function f(e){let t=e.elementLabel||`element`,n=e.valueEntered?.trim(),r=e.elementKind||``;switch(e.actionType){case`click`:return r===`link`?`Clicked the hyperlink ${l(t)}`:r===`button`?`Clicked the ${l(t)} button`:`Clicked ${l(t)}`;case`input`:return n?`Entered ${l(n)} in the ${l(t)} field`:`Typed in the ${l(t)} field`;case`select`:return n?`Selected ${l(n)} from the ${l(t)} dropdown`:`Changed the ${l(t)} dropdown`;case`check`:return r===`radio`?n?`Selected radio option ${l(n)} for ${l(t)}`:`Selected a radio option for ${l(t)}`:n===`checked`?`Checked the ${l(t)} checkbox`:n===`unchecked`?`Unchecked the ${l(t)} checkbox`:`Toggled the ${l(t)} checkbox`;case`submit`:return`Submitted the ${l(t)} form`;case`navigate`:return`Navigated to ${l(t)}`;default:return`Interacted with ${l(t)}`}}function p(e){let t=e.elementLabel||`element`,n=e.valueEntered?.trim(),r=e.elementKind||``;switch(e.actionType){case`click`:return r===`link`?`Hyperlink ${l(t)} was activated and navigation/action started`:r===`button`?`${l(t)} button click was registered on the page`:`${l(t)} was clicked successfully`;case`input`:return n?`${l(t)} field accepted the value ${l(n)}`:`${l(t)} field accepted the typed input`;case`select`:return n?`${l(t)} dropdown updated to ${l(n)}`:`${l(t)} dropdown selection was updated`;case`check`:return r===`radio`?n?`Radio option ${l(n)} for ${l(t)} became selected`:`Radio selection for ${l(t)} was updated`:n===`unchecked`?`${l(t)} checkbox became unchecked`:`${l(t)} checkbox became checked`;case`submit`:return`${l(t)} form submit was triggered`;case`navigate`:return`Page ${l(t)} loaded in the browser`;default:return`Interaction with ${l(t)} completed on the page`}}var m=2560,h=42e4,g=.72,_=.88;function v(e){let t=e.indexOf(`,`),n=t>=0?e.slice(t+1):e;return Math.floor(n.length*3/4)}async function y(e,t,n){if(e instanceof HTMLCanvasElement)return e.toDataURL(t,n);let r=await(await e.convertToBlob({type:t,quality:n})).arrayBuffer(),i=new Uint8Array(r),a=``;for(let e=0;e<i.length;e++)a+=String.fromCharCode(i[e]);return`data:${t};base64,${btoa(a)}`}function b(){try{let e=document.createElement(`canvas`);return e.width=1,e.height=1,e.toDataURL(`image/webp`).startsWith(`data:image/webp`)}catch{return!1}}function x(e,t,n=m){let r=Math.max(e,t);if(r<=n)return{width:e,height:t,scale:1};let i=n/r;return{width:Math.max(1,Math.round(e*i)),height:Math.max(1,Math.round(t*i)),scale:i}}async function S(e){let{width:t,height:n}=x(e.width,e.height),r=document.createElement(`canvas`);r.width=t,r.height=n;let i=r.getContext(`2d`);if(!i){let t=e.toDataURL(`image/jpeg`,_);return{dataUrl:t,contentType:`image/jpeg`,bytes:v(t)}}i.imageSmoothingEnabled=!0,i.imageSmoothingQuality=`high`,i.drawImage(e,0,0,t,n);let a=b()?`image/webp`:`image/jpeg`,o=_,s=await y(r,a,o),c=v(s);for(;c>h&&o>g;)o=Math.max(g,o-.06),s=await y(r,a,o),c=v(s);if(c>h*1.35&&Math.max(t,n)>1920){let e=x(t,n,1920),i=document.createElement(`canvas`);i.width=e.width,i.height=e.height;let l=i.getContext(`2d`);l&&(l.imageSmoothingEnabled=!0,l.imageSmoothingQuality=`high`,l.drawImage(r,0,0,e.width,e.height),s=await y(i,a,Math.max(o,.8)),c=v(s))}return{dataUrl:s,contentType:a,bytes:c}}var C=`testbuddy-annotate-overlay`,w=[`#e11d48`,`#f59e0b`,`#22c55e`,`#3b82f6`,`#a855f7`,`#ffffff`,`#0f172a`];function T(e){document.getElementById(C)?.remove();let t=document.createElement(`div`);t.id=C,t.innerHTML=`
    <div class="tb-ann-panel" role="dialog" aria-modal="true">
      <div class="tb-ann-head">
        <div>
          <strong>Annotate screenshot</strong>
          <span>Mark the bug like Lightshot — then add a short overview</span>
        </div>
        <div class="tb-ann-quality" data-quality>HD capture</div>
      </div>

      <div class="tb-ann-workspace">
        <div class="tb-ann-toolbar" role="toolbar" aria-label="Annotation tools">
          <button type="button" data-tool="rect" title="Rectangle" class="is-active">▢</button>
          <button type="button" data-tool="highlight" title="Highlighter">▮</button>
          <button type="button" data-tool="arrow" title="Arrow">➤</button>
          <button type="button" data-tool="line" title="Line">╱</button>
          <button type="button" data-tool="pen" title="Freehand pen">✎</button>
          <button type="button" data-tool="text" title="Text label">T</button>
          <span class="tb-ann-sep"></span>
          <button type="button" data-act="undo" title="Undo">↶</button>
          <button type="button" data-act="clear" title="Clear all">⌫</button>
          <span class="tb-ann-sep"></span>
          <div class="tb-ann-colors" data-colors></div>
        </div>

        <div class="tb-ann-stage">
          <canvas class="tb-ann-canvas"></canvas>
        </div>
      </div>

      <div class="tb-ann-status" aria-live="polite"></div>
      <label class="tb-ann-label">
        Bug overview
        <textarea class="tb-ann-overview" rows="2" maxlength="400"
          placeholder="e.g. Login button shows error instead of signing in"></textarea>
      </label>
      <div class="tb-ann-actions">
        <button type="button" data-act="cancel">Cancel</button>
        <button type="button" class="tb-ann-primary" data-act="save">Save annotated shot</button>
      </div>
      <div class="tb-ann-hint">
        Tip: use Highlight or Rectangle on the defect. Arrow/pen for callouts. Text for short notes.
      </div>
    </div>
  `,document.documentElement.appendChild(t);let n=t.querySelector(`.tb-ann-panel`),r=t.querySelector(`.tb-ann-canvas`),i=t.querySelector(`.tb-ann-overview`),a=t.querySelector(`.tb-ann-status`),o=t.querySelector(`[data-quality]`),s=t.querySelector(`[data-colors]`),c=r.getContext(`2d`,{alpha:!1});if(!c){t.remove(),e.onCancel();return}let l=c,u=`rect`,d=w[0],f=[],p=null,m=[],h=null,g=!1,_=new Image;s.innerHTML=w.map(e=>`<button type="button" data-color="${e}" style="--swatch:${e}" class="${e===d?`is-active`:``}" title="${e}"></button>`).join(``);function v(e,t=`info`){a.textContent=e,a.dataset.kind=t}function y(e){u=e,t.querySelectorAll(`[data-tool]`).forEach(t=>{t.classList.toggle(`is-active`,t.dataset.tool===e)}),r.dataset.tool=e,v(e===`text`?`Click where the text should appear.`:`Tool: ${e} — drag on the image to draw.`,`info`)}function b(e){d=e,s.querySelectorAll(`button`).forEach(t=>{t.classList.toggle(`is-active`,t.dataset.color===e)})}function x(){return Math.max(2.5,Math.round(r.width/700))}function T(e,t,n,r,i,a,o){let s=Math.atan2(i-n,r-t),c=Math.max(12,o*4);e.beginPath(),e.moveTo(r,i),e.lineTo(r-c*Math.cos(s-.4),i-c*Math.sin(s-.4)),e.lineTo(r-c*Math.cos(s+.4),i-c*Math.sin(s+.4)),e.closePath(),e.fillStyle=a,e.fill()}function E(e,t){switch(e.save(),e.lineCap=`round`,e.lineJoin=`round`,t.type){case`rect`:e.lineWidth=t.width,e.strokeStyle=t.color,e.fillStyle=t.color+`33`,e.fillRect(t.x,t.y,t.w,t.h),e.strokeRect(t.x+.5,t.y+.5,t.w,t.h);break;case`highlight`:e.fillStyle=t.color+`55`,e.fillRect(t.x,t.y,t.w,t.h),e.lineWidth=Math.max(2,t.width*.6),e.strokeStyle=t.color,e.strokeRect(t.x+.5,t.y+.5,t.w,t.h);break;case`line`:e.strokeStyle=t.color,e.lineWidth=t.width,e.beginPath(),e.moveTo(t.x1,t.y1),e.lineTo(t.x2,t.y2),e.stroke();break;case`arrow`:e.strokeStyle=t.color,e.lineWidth=t.width,e.beginPath(),e.moveTo(t.x1,t.y1),e.lineTo(t.x2,t.y2),e.stroke(),T(e,t.x1,t.y1,t.x2,t.y2,t.color,t.width);break;case`pen`:if(t.points.length<2)break;e.strokeStyle=t.color,e.lineWidth=t.width,e.beginPath(),e.moveTo(t.points[0].x,t.points[0].y);for(let n=1;n<t.points.length;n++)e.lineTo(t.points[n].x,t.points[n].y);e.stroke();break;case`text`:e.fillStyle=t.color,e.font=`bold ${t.size}px "Segoe UI", sans-serif`,e.shadowColor=`rgba(0,0,0,0.35)`,e.shadowBlur=2,e.fillText(t.text,t.x,t.y);break}e.restore()}function D(){l.clearRect(0,0,r.width,r.height),_.complete&&_.naturalWidth>0&&(l.imageSmoothingEnabled=!0,l.imageSmoothingQuality=`high`,l.drawImage(_,0,0,r.width,r.height));for(let e of f)E(l,e);p&&E(l,p)}function O(e,t){let n=r.getBoundingClientRect(),i=(e-n.left)/Math.max(n.width,1)*r.width,a=(t-n.top)/Math.max(n.height,1)*r.height;return{x:Math.max(0,Math.min(r.width,i)),y:Math.max(0,Math.min(r.height,a))}}function k(){if(p){if((p.type===`rect`||p.type===`highlight`)&&(p.w<4||p.h<4)){p=null,D();return}if(p.type===`line`||p.type===`arrow`){let e=p.x2-p.x1,t=p.y2-p.y1;if(Math.hypot(e,t)<6){p=null,D();return}}if(p.type===`pen`&&p.points.length<2){p=null,D();return}f.push(p),p=null,v(`${f.length} mark(s) on screenshot.`,`ok`),D()}}function A(e,t,n){let i=O(e,t);if(u===`text`){let e=window.prompt(`Text to place on screenshot:`,``);if(e?.trim()){let t=Math.max(16,Math.round(r.width/55));f.push({type:`text`,x:i.x,y:i.y,text:e.trim().slice(0,120),color:d,size:t}),v(`Text added.`,`ok`),D()}return}g=!0,h=i;let a=x();if(u===`pen`?(m=[{...i}],p={type:`pen`,points:[...m],color:d,width:a}):u===`rect`?p={type:`rect`,x:i.x,y:i.y,w:0,h:0,color:d,width:a}:u===`highlight`?p={type:`highlight`,x:i.x,y:i.y,w:0,h:0,color:d,width:a}:u===`line`?p={type:`line`,x1:i.x,y1:i.y,x2:i.x,y2:i.y,color:d,width:a}:u===`arrow`&&(p={type:`arrow`,x1:i.x,y1:i.y,x2:i.x,y2:i.y,color:d,width:a}),n!=null)try{r.setPointerCapture(n)}catch{}}function j(e,t){if(!g||!h||!p)return;let n=O(e,t);p.type===`pen`?(m.push(n),p={...p,points:[...m]}):p.type===`rect`||p.type===`highlight`?p={...p,x:Math.min(h.x,n.x),y:Math.min(h.y,n.y),w:Math.abs(n.x-h.x),h:Math.abs(n.y-h.y)}:(p.type===`line`||p.type===`arrow`)&&(p={...p,x2:n.x,y2:n.y}),D()}function M(){g&&(g=!1,h=null,k())}_.onload=()=>{let e=2560,t=Math.max(_.naturalWidth,_.naturalHeight),n=t>e?e/t:1;r.width=Math.max(1,Math.round(_.naturalWidth*n)),r.height=Math.max(1,Math.round(_.naturalHeight*n));let i=Math.min(window.innerWidth-120,1100),a=Math.min(window.innerHeight-280,720),s=Math.min(i/r.width,a/r.height,1);r.style.width=`${Math.round(r.width*s)}px`,r.style.height=`${Math.round(r.height*s)}px`,o.textContent=`${r.width}×${r.height} · sharp encode`,D(),v(`Pick a tool, mark the bug, then save.`,`info`)},_.onerror=()=>v(`Could not load screenshot image.`,`error`),_.src=e.dataUrl,r.addEventListener(`pointerdown`,e=>{e.preventDefault(),e.stopPropagation(),A(e.clientX,e.clientY,e.pointerId)}),r.addEventListener(`pointermove`,e=>{g&&(e.preventDefault(),e.stopPropagation(),j(e.clientX,e.clientY))}),r.addEventListener(`pointerup`,e=>{e.preventDefault(),e.stopPropagation(),M()}),r.addEventListener(`pointercancel`,()=>M()),window.addEventListener(`mousemove`,N),window.addEventListener(`mouseup`,P);function N(e){g&&j(e.clientX,e.clientY)}function P(){g&&M()}let F=e=>e.stopPropagation();for(let e of[`click`,`mousedown`,`mouseup`,`mousemove`,`pointerdown`,`keydown`,`keyup`])t.addEventListener(e,F,!1);t.addEventListener(`mousedown`,e=>{e.target===t&&e.preventDefault()}),n.addEventListener(`mousedown`,e=>e.stopPropagation()),t.querySelectorAll(`[data-tool]`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),y(e.dataset.tool)})}),s.querySelectorAll(`button`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation();let n=e.dataset.color;n&&b(n)})}),t.querySelectorAll(`button[data-act]`).forEach(t=>{t.addEventListener(`click`,n=>{n.preventDefault(),n.stopPropagation();let a=t.dataset.act;a===`undo`?(f.pop(),D(),v(f.length?`${f.length} mark(s) left.`:`Cleared last mark.`,`info`)):a===`clear`?(f.length=0,p=null,D(),v(`All marks cleared.`,`info`)):a===`cancel`?(I(),e.onCancel()):a===`save`&&(async()=>{let t=i.value.trim();if(!t){i.focus(),v(`Please enter a short bug overview.`,`error`);return}if(!f.length){v(`Add at least one highlight / arrow / mark first.`,`error`);return}v(`Encoding sharp screenshot…`,`info`);try{D();let n=await S(r),i=Math.round(n.bytes/1024);o.textContent=`${r.width}×${r.height} · ${i} KB`,I(),e.onSave({dataUrl:n.dataUrl,overview:t,annotations:f.slice()})}catch(e){v(e instanceof Error?e.message:`Encode failed`,`error`)}})()})});function I(){window.removeEventListener(`mousemove`,N),window.removeEventListener(`mouseup`,P),t.remove()}setTimeout(()=>i.focus(),80)}var E=`testbuddy-recorder-root`,D=`testbuddy-recorder-style`,O=window===window.top;window.__testbuddyRecorderInstalled||(window.__testbuddyRecorderInstalled=!0,k());function k(){let e=null,t=!1,n=``,r=0,i=!1,a=null,o=t=>{if(i||!e||e.status!==`recording`)return;let n=t.target;if(!(n instanceof Element)||n.closest(`#${E}`))return;if(t.type===`submit`){let e=n instanceof HTMLFormElement?n:n.closest(`form`);if(!e)return;let t=A(e,`submit`);if(!t)return;s(t);return}if(n instanceof HTMLLabelElement||n.closest(`label`)){let e=I(n instanceof HTMLLabelElement?n:n.closest(`label`));e&&(n=e)}let r=F(n,t.type);if(!r||t.type===`click`&&(N(r)||P(r)||r instanceof HTMLSelectElement)||t.type===`keydown`&&(t.key!==`Enter`||!N(r))||t.type===`blur`&&!N(r)||t.type===`input`&&N(r))return;let a=A(r,t.type);a&&s(a)};function s(e){let t=`${e.actionType}|${e.selector}|${e.valueEntered||``}|${e.description}`,i=Date.now();t===n&&i-r<400||(n=t,r=i,c.default.runtime.sendMessage({type:`ADD_STEP`,step:{actionType:e.actionType,elementLabel:e.elementLabel,selector:e.selector,valueEntered:e.valueEntered,pageUrl:e.pageUrl,description:e.description,actualResult:e.actualResult,expectedResult:e.expectedResult}}).catch(e=>console.warn(`TestBuddy ADD_STEP failed`,e)))}function l(){t||(t=!0,document.addEventListener(`click`,o,!0),document.addEventListener(`change`,o,!0),document.addEventListener(`blur`,o,!0),document.addEventListener(`input`,o,!0),document.addEventListener(`keydown`,o,!0),document.addEventListener(`submit`,o,!0))}function d(){t&&(t=!1,document.removeEventListener(`click`,o,!0),document.removeEventListener(`change`,o,!0),document.removeEventListener(`blur`,o,!0),document.removeEventListener(`input`,o,!0),document.removeEventListener(`keydown`,o,!0),document.removeEventListener(`submit`,o,!0))}function f(){K(),document.querySelectorAll(`#${E}`).forEach((e,t)=>{t>0&&e.remove()});let e=document.getElementById(E);return e||(e=document.createElement(`div`),e.id=E,document.documentElement.appendChild(e)),e}function p(){if(!O){document.getElementById(E)?.remove(),e&&(e.status===`recording`||e.status===`paused`)&&!i?l():d();return}if(i||!e||e.status!==`recording`&&e.status!==`paused`){document.getElementById(E)?.remove(),i||d();return}l();let t=f(),n=[...e.steps].slice(-8).reverse(),r=e.screenshots?.length||0;t.innerHTML=`
      <div class="rs-bar">
        <div class="rs-top">
          <div class="rs-brand">
            <span class="rs-dot ${e.status}"></span>
            <strong>TestBuddy</strong>
            <span class="rs-status">${e.status===`paused`?`Paused`:`Recording`}</span>
          </div>
          <div class="rs-count" title="Recorded steps">
            <span class="rs-count-num">${e.steps.length}</span>
            <span class="rs-count-label">steps</span>
          </div>
        </div>
        <div class="rs-actions rs-actions-3">
          ${e.status===`recording`?`<button type="button" data-action="pause">Pause</button>`:`<button type="button" data-action="resume">Resume</button>`}
          <button type="button" data-action="capture">Screenshot</button>
          <button type="button" class="rs-stop" data-action="stop">Stop</button>
        </div>
        ${r?`<div class="rs-shots">${r} screenshot${r===1?``:`s`} with highlights</div>`:``}
        <div class="rs-feed" aria-live="polite">
          ${n.length===0?`<div class="rs-empty">Interact with the page — or capture a screenshot to mark the bug.</div>`:n.map(e=>`
            <div class="rs-event">
              <div class="rs-event-head">
                <span class="rs-event-order">Step ${e.order}</span>
                <span class="rs-event-type">${e.actionType}</span>
                ${e.screenshotId?`<span class="rs-shot-tag">bug</span>`:``}
              </div>
              <div class="rs-event-text"><strong>Step:</strong> ${u(e.description)}</div>
              ${e.actualResult?`<div class="rs-actual"><strong>Actual:</strong> ${u(e.actualResult)}</div>`:``}
              ${e.expectedResult?`<div class="rs-expected"><strong>Expected:</strong> ${u(e.expectedResult)}</div>`:``}
            </div>`).join(``)}
        </div>
      </div>
    `,t.querySelectorAll(`button[data-action]`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation();let n=e.dataset.action;n===`pause`&&g(`PAUSE_RECORDING`),n===`resume`&&g(`RESUME_RECORDING`),n===`stop`&&g(`STOP_RECORDING`),n===`capture`&&m()})})}async function m(){if(!(!O||i||!e)){a=e.status,i=!0,d(),document.getElementById(E)?.remove(),a===`recording`&&await g(`PAUSE_RECORDING`,{skipRender:!0});try{let t=await c.default.runtime.sendMessage({type:`CAPTURE_VISIBLE_TAB`});if(!t?.ok||!t.dataUrl)throw Error(t?.error||`Could not capture screenshot`);T({dataUrl:t.dataUrl,onCancel:()=>{h(!1)},onSave:t=>{(async()=>{try{let n=await c.default.runtime.sendMessage({type:`SAVE_BUG_CAPTURE`,overview:t.overview,dataUrl:t.dataUrl,pageUrl:location.href,annotations:t.annotations});if(!n?.ok||!n.session)throw Error(n?.error||`Could not save screenshot step`);e=n.session,await h(!0)}catch(e){let t=e instanceof Error?e.message:`Save failed`;console.warn(`Save capture failed`,e),window.alert(`TestBuddy: screenshot step not saved.\n${t}`),await h(!1)}})()}})}catch(e){console.warn(`Screenshot capture failed`,e);let t=e instanceof Error?e.message:`Capture failed`;window.alert(`TestBuddy: could not capture screenshot.\n${t}`),await h(!1)}}}async function h(t){i=!1;let n=a;if(a=null,n===`recording`)await g(`RESUME_RECORDING`);else{try{let t=await c.default.runtime.sendMessage({type:`GET_RECORDING_STATE`});t?.ok&&t.session&&(e=t.session)}catch{}p()}t&&e&&p()}async function g(t,n){let r=await c.default.runtime.sendMessage({type:t});r?.ok&&r.session&&(e=r.session,n?.skipRender||p())}c.default.runtime.onMessage.addListener(t=>{let n=t;n?.type===`RECORDING_SYNC`&&n.session&&(e=n.session,p())}),c.default.storage.onChanged.addListener((t,n)=>{n!==`local`||!t.recordingSession||(e=t.recordingSession.newValue||null,p())}),c.default.runtime.sendMessage({type:`CONTENT_READY`}).then(t=>{let n=t;n?.ok&&n.session&&(e=n.session,p())})}function A(e,t){let n=M(e),r=j(e,t,n);if(!r)return null;let i=B(e,n),a=L(e),o=f({actionType:r,elementLabel:i,valueEntered:a,elementKind:n}),s=p({actionType:r,elementLabel:i,valueEntered:a,elementKind:n});return{actionType:r,elementLabel:i,selector:W(e),valueEntered:a,pageUrl:location.href,description:o,actualResult:s,elementKind:n}}function j(e,t,n){return t===`submit`||n===`form`?`submit`:n===`select`?`select`:n===`checkbox`||n===`radio`?`check`:n===`input`||n===`textarea`?`input`:n===`link`||n===`button`||n===`clickable`||t===`click`?`click`:null}function M(e){return e instanceof HTMLSelectElement?`select`:e instanceof HTMLTextAreaElement?`textarea`:e instanceof HTMLFormElement?`form`:e instanceof HTMLAnchorElement||e.getAttribute(`role`)===`link`?`link`:e instanceof HTMLButtonElement||e.getAttribute(`role`)===`button`||e instanceof HTMLInputElement&&[`button`,`submit`,`reset`,`image`].includes(e.type)?`button`:e instanceof HTMLInputElement?e.type===`checkbox`?`checkbox`:e.type===`radio`?`radio`:`input`:e.isContentEditable?`input`:`clickable`}function N(e){return e instanceof HTMLTextAreaElement||e.isContentEditable?!0:e instanceof HTMLInputElement&&![`checkbox`,`radio`,`button`,`submit`,`reset`,`image`,`file`,`hidden`].includes(e.type)}function P(e){return e instanceof HTMLInputElement&&(e.type===`checkbox`||e.type===`radio`)}function F(e,t){return e.closest([`a[href]`,`button`,`input`,`textarea`,`select`,`summary`,`[role='button']`,`[role='link']`,`[role='checkbox']`,`[role='radio']`,`[role='tab']`,`[role='menuitem']`,`[role='option']`,`[role='switch']`,`[contenteditable='true']`,`[onclick]`,`[tabindex]:not([tabindex='-1'])`].join(`, `))||(t===`click`&&e instanceof HTMLElement?e.closest(`div, span, li, td, th, p, section, article, header, footer, nav, main, aside`)||e:null)}function I(e){return e?e.control?e.control:e.querySelector(`input, select, textarea`):null}function L(e){if(e instanceof HTMLInputElement)return e.type===`password`||z(e)?`••••`:e.type===`checkbox`?e.checked?`checked`:`unchecked`:e.type===`radio`?e.checked?R(e)||e.value||`selected`:void 0:e.value||void 0;if(e instanceof HTMLTextAreaElement)return z(e)?`••••`:e.value||void 0;if(e instanceof HTMLSelectElement)return(e.selectedOptions[0]?.textContent||e.value||``).trim()||void 0;if(e.isContentEditable)return(e.innerText||``).trim()||void 0;if(e instanceof HTMLAnchorElement)return e.href||void 0}function R(e){if(e.id){let t=V(document.querySelector(`label[for="${G(e.id)}"]`),e);if(t)return t}return V(e.closest(`label`),e)||H(e)||void 0}function z(e){if(!(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement))return!1;if(e instanceof HTMLInputElement&&e.type===`password`)return!0;let t=(e.getAttribute(`autocomplete`)||``).toLowerCase();if(t.includes(`password`)||t.includes(`cc-`)||t.includes(`one-time`))return!0;let n=`${e.name} ${e.id} ${e.className}`.toLowerCase();return/password|passwd|secret|ssn|credit|card.?number/.test(n)}function B(e,t){if(e instanceof HTMLElement){let t=e.getAttribute(`aria-label`)?.trim();if(t)return U(t)}if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement){if(e.id){let n=V(document.querySelector(`label[for="${G(e.id)}"]`),e);if(n&&t!==`radio`||n&&t===`checkbox`)return n}let n=V(e.closest(`label`),e);if(n&&t===`checkbox`||n&&t!==`radio`)return n;if(t===`radio`){let t=e.closest(`fieldset`)?.querySelector(`legend`);if(t?.textContent?.trim())return U(t.textContent);let n=e.getAttribute(`aria-labelledby`);if(n){let e=document.getElementById(n);if(e?.textContent?.trim())return U(e.textContent)}if(e instanceof HTMLInputElement&&e.name)return U(e.name.replace(/[_-]+/g,` `))}if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){if(e.placeholder?.trim())return U(e.placeholder);let t=e.getAttribute(`title`)?.trim();if(t)return U(t)}if(e.name)return U(e.name.replace(/[_-]+/g,` `))}if(e instanceof HTMLButtonElement||e instanceof HTMLInputElement){let t=e.value?.trim();if(t&&[`button`,`submit`,`reset`].includes(e.type||`button`))return U(t)}if(e instanceof HTMLAnchorElement)return U(e.innerText||e.textContent||``)||e.href||`link`;if(e instanceof HTMLFormElement){let t=e.getAttribute(`name`)?.trim()||e.getAttribute(`aria-label`)?.trim();return t?U(t):e.id?U(e.id.replace(/[_-]+/g,` `)):`form`}if(e instanceof HTMLElement){let t=U(e.innerText||e.textContent||``);if(t)return t.slice(0,80)}return e.tagName.toLowerCase()}function V(e,t){if(!e)return null;let n=e.cloneNode(!0);n.querySelectorAll(`input, select, textarea, button`).forEach(e=>e.remove());let r=U(n.textContent||``);return r?r.slice(0,80):null}function H(e){let t=e.parentElement;if(!t)return null;let n=U(t.innerText||t.textContent||``);return n?n.slice(0,80):null}function U(e){return e.replace(/\s+/g,` `).trim()}function W(e){if(e.id)return`#${G(e.id)}`;let t=[],n=e;for(;n&&t.length<4;){let e=n.tagName.toLowerCase();n.classList.length&&(e+=`.`+Array.from(n.classList).slice(0,2).map(G).join(`.`)),t.unshift(e),n=n.parentElement}return t.join(` > `)}function G(e){return typeof CSS<`u`&&CSS.escape?CSS.escape(e):e.replace(/[^a-zA-Z0-9_-]/g,`\\$&`)}function K(){if(document.getElementById(D))return;let e=document.createElement(`style`);e.id=D,e.textContent=`
    #${E} {
      all: initial;
      position: fixed;
      z-index: 2147483646;
      right: 16px;
      bottom: 16px;
      width: 340px;
      font-family: "Segoe UI", "IBM Plex Sans", sans-serif;
      color: #1a2332;
    }
    #${E} * { box-sizing: border-box; font-family: inherit; }
    #${E} .rs-bar {
      background: rgba(255,255,255,0.97);
      border: 1px solid #d7dee7;
      border-radius: 14px;
      box-shadow: 0 12px 40px rgba(26,35,50,0.18);
      padding: 12px;
      backdrop-filter: blur(8px);
    }
    #${E} .rs-top {
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
    }
    #${E} .rs-brand {
      display: flex; align-items: center; gap: 8px; font-size: 13px;
    }
    #${E} .rs-dot {
      width: 8px; height: 8px; border-radius: 50%; background: #0f6e56;
      box-shadow: 0 0 0 4px rgba(15,110,86,0.15);
    }
    #${E} .rs-dot.paused { background: #b45309; box-shadow: 0 0 0 4px rgba(180,83,9,0.15); }
    #${E} .rs-status { color: #5c6b7a; font-size: 12px; }
    #${E} .rs-count { display: flex; flex-direction: column; align-items: flex-end; line-height: 1.1; }
    #${E} .rs-count-num { font-size: 22px; font-weight: 700; color: #0f6e56; letter-spacing: -0.03em; }
    #${E} .rs-count-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.08em; color: #5c6b7a; }
    #${E} .rs-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
    #${E} .rs-actions-3 { grid-template-columns: 1fr 1fr 1fr; }
    #${E} button {
      border: 1px solid #d7dee7; background: #fff; border-radius: 10px;
      padding: 8px 6px; font-size: 11px; font-weight: 600; cursor: pointer; color: #1a2332;
    }
    #${E} button.rs-stop { background: #0f6e56; border-color: #0f6e56; color: #fff; }
    #${E} .rs-shots {
      margin-top: 8px; font-size: 11px; color: #0f6e56; font-weight: 600;
    }
    #${E} .rs-feed {
      margin-top: 10px; max-height: 220px; overflow: auto;
      display: flex; flex-direction: column; gap: 6px;
    }
    #${E} .rs-empty {
      font-size: 12px; color: #5c6b7a; padding: 8px; background: #f3f6f9; border-radius: 8px;
    }
    #${E} .rs-event {
      font-size: 11px; padding: 8px; border-radius: 8px; background: #e6f4ef;
      animation: rs-pop 180ms ease-out;
    }
    #${E} .rs-event-head {
      display: flex; gap: 6px; align-items: center; margin-bottom: 4px; flex-wrap: wrap;
    }
    #${E} .rs-event-order { font-weight: 700; color: #0f6e56; }
    #${E} .rs-event-type {
      text-transform: uppercase; letter-spacing: 0.04em; color: #5c6b7a; font-size: 10px;
    }
    #${E} .rs-shot-tag {
      font-size: 9px; text-transform: uppercase; letter-spacing: 0.06em;
      background: #ffe4e6; color: #be123c; padding: 2px 6px; border-radius: 999px; font-weight: 700;
    }
    #${E} .rs-actual-tag {
      margin-left: auto; font-size: 9px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.05em; color: #0f6e56; background: #fff; border: 1px solid #c5ddd3;
      padding: 2px 6px; border-radius: 999px; white-space: nowrap;
    }
    #${E} .rs-event-text { color: #1a2332; line-height: 1.35; }
    #${E} .rs-event-text strong { font-weight: 700; color: #0b4f3d; }
    #${E} .rs-actual {
      margin-top: 4px; color: #1a2332; font-size: 10.5px; line-height: 1.35;
    }
    #${E} .rs-actual strong { font-weight: 700; color: #0f6e56; margin-right: 4px; }
    #${E} .rs-actual strong + * , #${E} .rs-actual { }
    #${E} .rs-expected {
      margin-top: 4px; padding-top: 4px; border-top: 1px dashed #f0b4b4;
      color: #9b1c1c; font-size: 10.5px; line-height: 1.35;
    }
    #${E} .rs-expected strong { font-weight: 700; color: #9b1c1c; margin-right: 4px; }
    @keyframes rs-pop {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }

    #testbuddy-annotate-overlay {
      all: initial;
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      background: rgba(15, 23, 32, 0.78);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 12px;
      font-family: "Segoe UI", "IBM Plex Sans", sans-serif;
      color: #1a2332;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay * { box-sizing: border-box; font-family: inherit; }
    #testbuddy-annotate-overlay .tb-ann-panel {
      width: min(1180px, 100%);
      background: #fff;
      border-radius: 16px;
      padding: 12px;
      box-shadow: 0 24px 64px rgba(0,0,0,0.4);
      display: flex;
      flex-direction: column;
      gap: 10px;
      max-height: calc(100vh - 24px);
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-head {
      display: flex; align-items: flex-start; justify-content: space-between; gap: 12px;
    }
    #testbuddy-annotate-overlay .tb-ann-head strong { display:block; font-size: 16px; }
    #testbuddy-annotate-overlay .tb-ann-head span { font-size: 12px; color: #5c6b7a; }
    #testbuddy-annotate-overlay .tb-ann-quality {
      flex-shrink: 0;
      font-size: 11px;
      font-weight: 700;
      color: #0f6e56;
      background: #e7f8f1;
      border-radius: 999px;
      padding: 4px 10px;
      white-space: nowrap;
    }
    #testbuddy-annotate-overlay .tb-ann-workspace {
      display: flex;
      gap: 10px;
      align-items: stretch;
      min-height: 0;
    }
    #testbuddy-annotate-overlay .tb-ann-toolbar {
      display: flex;
      flex-direction: column;
      gap: 6px;
      padding: 8px 6px;
      background: #0f172a;
      border-radius: 14px;
      align-items: center;
    }
    #testbuddy-annotate-overlay .tb-ann-toolbar button {
      width: 36px; height: 36px;
      border: none; border-radius: 10px;
      background: transparent; color: #e2e8f0;
      font-size: 15px; font-weight: 700; cursor: pointer;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-toolbar button:hover {
      background: rgba(255,255,255,0.1);
    }
    #testbuddy-annotate-overlay .tb-ann-toolbar button.is-active {
      background: #0d9488; color: #fff;
    }
    #testbuddy-annotate-overlay .tb-ann-sep {
      width: 24px; height: 1px; background: rgba(255,255,255,0.2); margin: 2px 0;
    }
    #testbuddy-annotate-overlay .tb-ann-colors {
      display: flex; flex-direction: column; gap: 5px; padding-top: 2px;
    }
    #testbuddy-annotate-overlay .tb-ann-colors button {
      width: 18px; height: 18px; border-radius: 999px;
      background: var(--swatch); border: 2px solid transparent; padding: 0;
    }
    #testbuddy-annotate-overlay .tb-ann-colors button.is-active {
      outline: 2px solid #fff; outline-offset: 1px;
    }
    #testbuddy-annotate-overlay .tb-ann-stage {
      flex: 1;
      overflow: auto; background: #0f1720; border-radius: 12px;
      display: flex; justify-content: center; align-items: center; padding: 10px;
      pointer-events: auto; min-width: 0;
    }
    #testbuddy-annotate-overlay .tb-ann-canvas {
      cursor: crosshair;
      border-radius: 4px;
      touch-action: none;
      pointer-events: auto !important;
      user-select: none;
      display: block;
      box-shadow: 0 0 0 1px rgba(255,255,255,0.08);
    }
    #testbuddy-annotate-overlay .tb-ann-canvas[data-tool="text"] { cursor: text; }
    #testbuddy-annotate-overlay .tb-ann-status {
      min-height: 18px;
      font-size: 12px;
      font-weight: 600;
      color: #5c6b7a;
    }
    #testbuddy-annotate-overlay .tb-ann-status[data-kind="ok"] { color: #0f6e56; }
    #testbuddy-annotate-overlay .tb-ann-status[data-kind="error"] { color: #be123c; }
    #testbuddy-annotate-overlay .tb-ann-label {
      display: flex; flex-direction: column; gap: 6px;
      font-size: 12px; font-weight: 600; color: #3d4f5f;
    }
    #testbuddy-annotate-overlay .tb-ann-overview {
      width: 100%; resize: vertical; min-height: 52px;
      border: 1px solid #d7dee7; border-radius: 10px; padding: 10px;
      font-size: 13px; font-weight: 400; color: #1a2332;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-actions {
      display: flex; gap: 8px; justify-content: flex-end; flex-wrap: wrap;
    }
    #testbuddy-annotate-overlay .tb-ann-actions button {
      border: 1px solid #d7dee7; background: #fff; border-radius: 10px;
      padding: 9px 12px; font-size: 12px; font-weight: 600; cursor: pointer;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-primary {
      background: #0f6e56 !important; border-color: #0f6e56 !important; color: #fff !important;
    }
    #testbuddy-annotate-overlay .tb-ann-hint {
      font-size: 11px; color: #5c6b7a;
    }
  `,document.documentElement.appendChild(e)}})();