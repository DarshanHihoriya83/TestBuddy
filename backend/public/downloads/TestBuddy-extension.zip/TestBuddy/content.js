(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=((n,r,a)=>(a=n==null?{}:e(i(n)),s(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n)))(o(((e,t)=>{(function(n,r){if(typeof define==`function`&&define.amd)define(`webextension-polyfill`,[`module`],r);else if(e!==void 0)r(t);else{var i={exports:{}};r(i),n.browser=i.exports}})(typeof globalThis<`u`?globalThis:typeof self<`u`?self:e,function(e){"use strict";if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw Error(`This script should only be loaded in a browser extension.`);globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id?e.exports=globalThis.browser:e.exports=(e=>{let t={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(t).length===0)throw Error(`api-metadata.json has not been included in browser-polyfill`);class n extends WeakMap{constructor(e,t=void 0){super(t),this.createItem=e}get(e){return this.has(e)||this.set(e,this.createItem(e)),super.get(e)}}let r=e=>e&&typeof e==`object`&&typeof e.then==`function`,i=(t,n)=>(...r)=>{e.runtime.lastError?t.reject(Error(e.runtime.lastError.message)):n.singleCallbackArg||r.length<=1&&n.singleCallbackArg!==!1?t.resolve(r[0]):t.resolve(r)},a=e=>e==1?`argument`:`arguments`,o=(e,t)=>function(n,...r){if(r.length<t.minArgs)throw Error(`Expected at least ${t.minArgs} ${a(t.minArgs)} for ${e}(), got ${r.length}`);if(r.length>t.maxArgs)throw Error(`Expected at most ${t.maxArgs} ${a(t.maxArgs)} for ${e}(), got ${r.length}`);return new Promise((a,o)=>{if(t.fallbackToNoCallback)try{n[e](...r,i({resolve:a,reject:o},t))}catch(i){console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,i),n[e](...r),t.fallbackToNoCallback=!1,t.noCallback=!0,a()}else t.noCallback?(n[e](...r),a()):n[e](...r,i({resolve:a,reject:o},t))})},s=(e,t,n)=>new Proxy(t,{apply(t,r,i){return n.call(r,e,...i)}}),c=Function.call.bind(Object.prototype.hasOwnProperty),l=(e,t={},n={})=>{let r=Object.create(null),i={has(t,n){return n in e||n in r},get(i,a,u){if(a in r)return r[a];if(!(a in e))return;let d=e[a];if(typeof d==`function`)if(typeof t[a]==`function`)d=s(e,e[a],t[a]);else if(c(n,a)){let t=o(a,n[a]);d=s(e,e[a],t)}else d=d.bind(e);else if(typeof d==`object`&&d&&(c(t,a)||c(n,a)))d=l(d,t[a],n[a]);else if(c(n,`*`))d=l(d,t[a],n[`*`]);else return Object.defineProperty(r,a,{configurable:!0,enumerable:!0,get(){return e[a]},set(t){e[a]=t}}),d;return r[a]=d,d},set(t,n,i,a){return n in r?r[n]=i:e[n]=i,!0},defineProperty(e,t,n){return Reflect.defineProperty(r,t,n)},deleteProperty(e,t){return Reflect.deleteProperty(r,t)}},a=Object.create(e);return new Proxy(a,i)},u=e=>({addListener(t,n,...r){t.addListener(e.get(n),...r)},hasListener(t,n){return t.hasListener(e.get(n))},removeListener(t,n){t.removeListener(e.get(n))}}),d=new n(e=>typeof e==`function`?function(t){e(l(t,{},{getContent:{minArgs:0,maxArgs:0}}))}:e),f=new n(e=>typeof e==`function`?function(t,n,i){let a=!1,o,s=new Promise(e=>{o=function(t){a=!0,e(t)}}),c;try{c=e(t,n,o)}catch(e){c=Promise.reject(e)}let l=c!==!0&&r(c);return c!==!0&&!l&&!a?!1:((e=>{e.then(e=>{i(e)},e=>{let t;t=e&&(e instanceof Error||typeof e.message==`string`)?e.message:`An unexpected error occurred`,i({__mozWebExtensionPolyfillReject__:!0,message:t})}).catch(e=>{console.error(`Failed to send onMessage rejected reply`,e)})})(l?c:s),!0)}:e),p=({reject:t,resolve:n},r)=>{e.runtime.lastError?e.runtime.lastError.message===`The message port closed before a response was received.`?n():t(Error(e.runtime.lastError.message)):r&&r.__mozWebExtensionPolyfillReject__?t(Error(r.message)):n(r)},m=(e,t,n,...r)=>{if(r.length<t.minArgs)throw Error(`Expected at least ${t.minArgs} ${a(t.minArgs)} for ${e}(), got ${r.length}`);if(r.length>t.maxArgs)throw Error(`Expected at most ${t.maxArgs} ${a(t.maxArgs)} for ${e}(), got ${r.length}`);return new Promise((e,t)=>{let i=p.bind(null,{resolve:e,reject:t});r.push(i),n.sendMessage(...r)})},h={devtools:{network:{onRequestFinished:u(d)}},runtime:{onMessage:u(f),onMessageExternal:u(f),sendMessage:m.bind(null,`sendMessage`,{minArgs:1,maxArgs:3})},tabs:{sendMessage:m.bind(null,`sendMessage`,{minArgs:2,maxArgs:3})}},g={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return t.privacy={network:{"*":g},services:{"*":g},websites:{"*":g}},l(e,h,t)})(chrome)})}))(),1);function l(e){return`**${e.replace(/\*\*/g,``)}**`}function u(e){return d(e).replace(/\*\*(.+?)\*\*/g,`<strong>$1</strong>`)}function d(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function f(e){let t=e.elementLabel||`element`,n=e.valueEntered?.trim(),r=e.elementKind||``;switch(e.actionType){case`click`:return r===`link`?`Clicked the hyperlink '${t}'`:r===`button`?`Clicked the '${t}' button`:`Clicked the '${t}'`;case`input`:return n?`Entered ${l(n)} into the '${t}' field`:`Typed into the '${t}' field`;case`select`:return n?`Selected ${l(n)} from the '${t}' dropdown`:`Changed the '${t}' dropdown`;case`check`:return r===`radio`?n?`Selected radio option ${l(n)} for '${t}'`:`Selected a radio option for '${t}'`:n===`checked`?`Checked the '${t}' checkbox`:n===`unchecked`?`Unchecked the '${t}' checkbox`:`Toggled the '${t}' checkbox`;case`submit`:return`Submitted the '${t}' form`;case`navigate`:return`Navigated to ${t}`;default:return`Interacted with '${t}'`}}function p(e){let t=e.elementLabel||`element`,n=e.valueEntered?.trim(),r=e.elementKind||``;switch(e.actionType){case`click`:return r===`link`?`The hyperlink '${t}' should open the target page or section`:r===`button`?`The '${t}' button action should complete successfully`:`The '${t}' control should respond to the click`;case`input`:return n?`The '${t}' field should contain ${l(n)}`:`The '${t}' field should accept the typed text`;case`select`:return n?`The '${t}' dropdown should show ${l(n)} as selected`:`The '${t}' dropdown selection should be updated`;case`check`:return r===`radio`?n?`The radio option ${l(n)} for '${t}' should be selected`:`The selected radio option for '${t}' should be active`:n===`unchecked`?`The '${t}' checkbox should be unchecked`:`The '${t}' checkbox should be checked`;case`submit`:return`The '${t}' form should submit and the expected result page or message should appear`;case`navigate`:return`The page '${t}' should load successfully`;default:return`The action on '${t}' should complete as expected`}}var m=`testbuddy-annotate-overlay`;function h(e){document.getElementById(m)?.remove();let t=document.createElement(`div`);t.id=m,t.innerHTML=`
    <div class="tb-ann-panel" role="dialog" aria-modal="true">
      <div class="tb-ann-head">
        <strong>Mark the bug</strong>
        <span>Drag on the image to highlight, add a short overview, then save</span>
      </div>
      <div class="tb-ann-stage">
        <canvas class="tb-ann-canvas"></canvas>
      </div>
      <div class="tb-ann-status" aria-live="polite"></div>
      <label class="tb-ann-label">
        Bug overview
        <textarea class="tb-ann-overview" rows="2" maxlength="400"
          placeholder="e.g. Accordion Section 1 does not expand after click"></textarea>
      </label>
      <div class="tb-ann-actions">
        <button type="button" data-act="clear">Clear box</button>
        <button type="button" data-act="cancel">Cancel</button>
        <button type="button" class="tb-ann-primary" data-act="save">Generate step &amp; save</button>
      </div>
      <div class="tb-ann-hint">Tip: click-drag on the screenshot to draw a red highlight box.</div>
    </div>
  `,document.documentElement.appendChild(t);let n=t.querySelector(`.tb-ann-panel`),r=t.querySelector(`.tb-ann-canvas`),i=t.querySelector(`.tb-ann-overview`),a=t.querySelector(`.tb-ann-status`),o=r.getContext(`2d`);if(!o){t.remove(),e.onCancel();return}let s=o,c=new Image,l=null,u=null,d=!1;function f(e,t=`info`){a.textContent=e,a.dataset.kind=t}c.onload=()=>{let e=Math.min(window.innerWidth-48,960),t=Math.min(window.innerHeight-240,640),n=Math.min(e/c.naturalWidth,t/c.naturalHeight,1);r.width=Math.max(1,Math.round(c.naturalWidth*n)),r.height=Math.max(1,Math.round(c.naturalHeight*n)),r.style.width=`${r.width}px`,r.style.height=`${r.height}px`,p(),f(`Draw a box on the bug area, then write an overview.`,`info`)},c.onerror=()=>{f(`Could not load screenshot image.`,`error`)},c.src=e.dataUrl;function p(){if(s.clearRect(0,0,r.width,r.height),c.complete&&c.naturalWidth>0&&s.drawImage(c,0,0,r.width,r.height),l&&l.w>1&&l.h>1){s.save(),s.lineWidth=Math.max(3,Math.round(r.width/400)),s.strokeStyle=`#e11d48`,s.fillStyle=`rgba(225, 29, 72, 0.22)`,s.fillRect(l.x,l.y,l.w,l.h),s.strokeRect(l.x+.5,l.y+.5,l.w,l.h),s.fillStyle=`#e11d48`;for(let[e,t]of[[l.x,l.y],[l.x+l.w,l.y],[l.x,l.y+l.h],[l.x+l.w,l.y+l.h]])s.fillRect(e-6/2,t-6/2,6,6);s.restore()}}function h(e,t){let n=r.getBoundingClientRect(),i=(e-n.left)/Math.max(n.width,1)*r.width,a=(t-n.top)/Math.max(n.height,1)*r.height;return{x:Math.max(0,Math.min(r.width,i)),y:Math.max(0,Math.min(r.height,a))}}function g(e,t,n){if(d=!0,u=h(e,t),l={type:`rect`,x:u.x,y:u.y,w:0,h:0},n!=null)try{r.setPointerCapture(n)}catch{}f(`Dragging highlight…`,`info`)}function _(e,t){if(!d||!u)return;let n=h(e,t);l={type:`rect`,x:Math.min(u.x,n.x),y:Math.min(u.y,n.y),w:Math.abs(n.x-u.x),h:Math.abs(n.y-u.y)},p()}function v(){d&&(d=!1,u=null,l&&l.w>=4&&l.h>=4?f(`Highlight ready (${Math.round(l.w)}×${Math.round(l.h)}). Add overview and save.`,`ok`):(l=null,p(),f(`Highlight too small — drag a larger box.`,`error`)))}r.addEventListener(`pointerdown`,e=>{e.preventDefault(),e.stopPropagation(),g(e.clientX,e.clientY,e.pointerId)}),r.addEventListener(`pointermove`,e=>{d&&(e.preventDefault(),e.stopPropagation(),_(e.clientX,e.clientY))}),r.addEventListener(`pointerup`,e=>{e.preventDefault(),e.stopPropagation(),v()}),r.addEventListener(`pointercancel`,()=>v()),r.addEventListener(`mousedown`,e=>{e.preventDefault(),e.stopPropagation(),g(e.clientX,e.clientY)}),window.addEventListener(`mousemove`,y),window.addEventListener(`mouseup`,b);function y(e){d&&_(e.clientX,e.clientY)}function b(){d&&v()}let x=e=>e.stopPropagation();for(let e of[`click`,`mousedown`,`mouseup`,`mousemove`,`pointerdown`,`keydown`,`keyup`])t.addEventListener(e,x,!1);t.addEventListener(`mousedown`,e=>{e.target===t&&e.preventDefault()}),n.addEventListener(`mousedown`,e=>e.stopPropagation()),t.querySelectorAll(`button[data-act]`).forEach(t=>{t.addEventListener(`click`,n=>{n.preventDefault(),n.stopPropagation();let a=t.dataset.act;if(a===`clear`)l=null,p(),f(`Highlight cleared — draw again.`,`info`);else if(a===`cancel`)S(),e.onCancel();else if(a===`save`){let t=i.value.trim();if(!t){i.focus(),f(`Please enter a short bug overview.`,`error`);return}let n=l&&l.w>=4&&l.h>=4?[l]:[];if(!n.length){f(`Draw a highlight box on the screenshot first.`,`error`);return}p();let a=r.toDataURL(`image/jpeg`,.75);S(),e.onSave({dataUrl:a,overview:t,annotations:n})}})});function S(){window.removeEventListener(`mousemove`,y),window.removeEventListener(`mouseup`,b),t.remove()}setTimeout(()=>i.focus(),50)}var g=`testbuddy-recorder-root`,_=`testbuddy-recorder-style`,v=window===window.top;window.__testbuddyRecorderInstalled||(window.__testbuddyRecorderInstalled=!0,y());function y(){let e=null,t=!1,n=``,r=0,i=!1,a=null,o=t=>{if(i||!e||e.status!==`recording`)return;let n=t.target;if(!(n instanceof Element)||n.closest(`#${g}`))return;if(t.type===`submit`){let e=n instanceof HTMLFormElement?n:n.closest(`form`);if(!e)return;let t=b(e,`submit`);if(!t)return;s(t);return}if(n instanceof HTMLLabelElement||n.closest(`label`)){let e=E(n instanceof HTMLLabelElement?n:n.closest(`label`));e&&(n=e)}let r=T(n,t.type);if(!r||t.type===`click`&&(C(r)||w(r)||r instanceof HTMLSelectElement)||t.type===`keydown`&&(t.key!==`Enter`||!C(r))||t.type===`blur`&&!C(r)||t.type===`input`&&C(r))return;let a=b(r,t.type);a&&s(a)};function s(e){let t=`${e.actionType}|${e.selector}|${e.valueEntered||``}|${e.description}`,i=Date.now();t===n&&i-r<400||(n=t,r=i,c.default.runtime.sendMessage({type:`ADD_STEP`,step:{actionType:e.actionType,elementLabel:e.elementLabel,selector:e.selector,valueEntered:e.valueEntered,pageUrl:e.pageUrl,description:e.description,expectedResult:e.expectedResult}}).catch(e=>console.warn(`TestBuddy ADD_STEP failed`,e)))}function l(){t||(t=!0,document.addEventListener(`click`,o,!0),document.addEventListener(`change`,o,!0),document.addEventListener(`blur`,o,!0),document.addEventListener(`input`,o,!0),document.addEventListener(`keydown`,o,!0),document.addEventListener(`submit`,o,!0))}function d(){t&&(t=!1,document.removeEventListener(`click`,o,!0),document.removeEventListener(`change`,o,!0),document.removeEventListener(`blur`,o,!0),document.removeEventListener(`input`,o,!0),document.removeEventListener(`keydown`,o,!0),document.removeEventListener(`submit`,o,!0))}function f(){I(),document.querySelectorAll(`#${g}`).forEach((e,t)=>{t>0&&e.remove()});let e=document.getElementById(g);return e||(e=document.createElement(`div`),e.id=g,document.documentElement.appendChild(e)),e}function p(){if(!v){document.getElementById(g)?.remove(),e&&(e.status===`recording`||e.status===`paused`)&&!i?l():d();return}if(i||!e||e.status!==`recording`&&e.status!==`paused`){document.getElementById(g)?.remove(),i||d();return}l();let t=f(),n=[...e.steps].slice(-8).reverse(),r=e.screenshots?.length||0;t.innerHTML=`
      <div class="rs-bar">
        <div class="rs-top">
          <div class="rs-brand">
            <span class="rs-dot ${e.status}"></span>
            <strong>TestBuddy</strong>
            <span class="rs-status">${e.status===`paused`?`Paused`:`Recording`}</span>
          </div>
          <div class="rs-count" title="Recorded steps">
            <span class="rs-count-num">${e.steps.length}</span>
            <span class="rs-count-label">steps</span>
          </div>
        </div>
        <div class="rs-actions rs-actions-3">
          ${e.status===`recording`?`<button type="button" data-action="pause">Pause</button>`:`<button type="button" data-action="resume">Resume</button>`}
          <button type="button" data-action="capture">Screenshot</button>
          <button type="button" class="rs-stop" data-action="stop">Stop</button>
        </div>
        ${r?`<div class="rs-shots">${r} screenshot${r===1?``:`s`} with highlights</div>`:``}
        <div class="rs-feed" aria-live="polite">
          ${n.length===0?`<div class="rs-empty">Interact with the page — or capture a screenshot to mark the bug.</div>`:n.map(e=>`
            <div class="rs-event">
              <div class="rs-event-head">
                <span class="rs-event-order">#${e.order}</span>
                <span class="rs-event-type">${e.actionType}</span>
                ${e.screenshotId?`<span class="rs-shot-tag">shot</span>`:``}
              </div>
              <div class="rs-event-text">${u(e.description)}</div>
              ${e.expectedResult?`<div class="rs-expected"><span>Expected:</span> ${u(e.expectedResult)}</div>`:``}
            </div>`).join(``)}
        </div>
      </div>
    `,t.querySelectorAll(`button[data-action]`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation();let n=e.dataset.action;n===`pause`&&y(`PAUSE_RECORDING`),n===`resume`&&y(`RESUME_RECORDING`),n===`stop`&&y(`STOP_RECORDING`),n===`capture`&&m()})})}async function m(){if(!(!v||i||!e)){a=e.status,i=!0,d(),document.getElementById(g)?.remove(),a===`recording`&&await y(`PAUSE_RECORDING`,{skipRender:!0});try{let t=await c.default.runtime.sendMessage({type:`CAPTURE_VISIBLE_TAB`});if(!t?.ok||!t.dataUrl)throw Error(t?.error||`Could not capture screenshot`);h({dataUrl:t.dataUrl,onCancel:()=>{_(!1)},onSave:t=>{(async()=>{try{let n=await c.default.runtime.sendMessage({type:`SAVE_BUG_CAPTURE`,overview:t.overview,dataUrl:t.dataUrl,pageUrl:location.href,annotations:t.annotations});if(!n?.ok||!n.session)throw Error(n?.error||`Could not save screenshot step`);e=n.session,await _(!0)}catch(e){let t=e instanceof Error?e.message:`Save failed`;console.warn(`Save capture failed`,e),window.alert(`TestBuddy: screenshot step not saved.\n${t}`),await _(!1)}})()}})}catch(e){console.warn(`Screenshot capture failed`,e);let t=e instanceof Error?e.message:`Capture failed`;window.alert(`TestBuddy: could not capture screenshot.\n${t}`),await _(!1)}}}async function _(t){i=!1;let n=a;if(a=null,n===`recording`)await y(`RESUME_RECORDING`);else{try{let t=await c.default.runtime.sendMessage({type:`GET_RECORDING_STATE`});t?.ok&&t.session&&(e=t.session)}catch{}p()}t&&e&&p()}async function y(t,n){let r=await c.default.runtime.sendMessage({type:t});r?.ok&&r.session&&(e=r.session,n?.skipRender||p())}c.default.runtime.onMessage.addListener(t=>{let n=t;n?.type===`RECORDING_SYNC`&&n.session&&(e=n.session,p())}),c.default.storage.onChanged.addListener((t,n)=>{n!==`local`||!t.recordingSession||(e=t.recordingSession.newValue||null,p())}),c.default.runtime.sendMessage({type:`CONTENT_READY`}).then(t=>{let n=t;n?.ok&&n.session&&(e=n.session,p())})}function b(e,t){let n=S(e),r=x(e,t,n);if(!r)return null;let i=A(e,n),a=D(e),o=f({actionType:r,elementLabel:i,valueEntered:a,elementKind:n}),s=p({actionType:r,elementLabel:i,valueEntered:a,elementKind:n});return{actionType:r,elementLabel:i,selector:P(e),valueEntered:a,pageUrl:location.href,description:o,expectedResult:s,elementKind:n}}function x(e,t,n){return t===`submit`||n===`form`?`submit`:n===`select`?`select`:n===`checkbox`||n===`radio`?`check`:n===`input`||n===`textarea`?`input`:n===`link`||n===`button`||n===`clickable`||t===`click`?`click`:null}function S(e){return e instanceof HTMLSelectElement?`select`:e instanceof HTMLTextAreaElement?`textarea`:e instanceof HTMLFormElement?`form`:e instanceof HTMLAnchorElement||e.getAttribute(`role`)===`link`?`link`:e instanceof HTMLButtonElement||e.getAttribute(`role`)===`button`||e instanceof HTMLInputElement&&[`button`,`submit`,`reset`,`image`].includes(e.type)?`button`:e instanceof HTMLInputElement?e.type===`checkbox`?`checkbox`:e.type===`radio`?`radio`:`input`:e.isContentEditable?`input`:`clickable`}function C(e){return e instanceof HTMLTextAreaElement||e.isContentEditable?!0:e instanceof HTMLInputElement&&![`checkbox`,`radio`,`button`,`submit`,`reset`,`image`,`file`,`hidden`].includes(e.type)}function w(e){return e instanceof HTMLInputElement&&(e.type===`checkbox`||e.type===`radio`)}function T(e,t){return e.closest([`a[href]`,`button`,`input`,`textarea`,`select`,`summary`,`[role='button']`,`[role='link']`,`[role='checkbox']`,`[role='radio']`,`[role='tab']`,`[role='menuitem']`,`[role='option']`,`[role='switch']`,`[contenteditable='true']`,`[onclick]`,`[tabindex]:not([tabindex='-1'])`].join(`, `))||(t===`click`&&e instanceof HTMLElement?e.closest(`div, span, li, td, th, p, section, article, header, footer, nav, main, aside`)||e:null)}function E(e){return e?e.control?e.control:e.querySelector(`input, select, textarea`):null}function D(e){if(e instanceof HTMLInputElement)return e.type===`password`||k(e)?`••••`:e.type===`checkbox`?e.checked?`checked`:`unchecked`:e.type===`radio`?e.checked?O(e)||e.value||`selected`:void 0:e.value||void 0;if(e instanceof HTMLTextAreaElement)return k(e)?`••••`:e.value||void 0;if(e instanceof HTMLSelectElement)return(e.selectedOptions[0]?.textContent||e.value||``).trim()||void 0;if(e.isContentEditable)return(e.innerText||``).trim()||void 0;if(e instanceof HTMLAnchorElement)return e.href||void 0}function O(e){if(e.id){let t=j(document.querySelector(`label[for="${F(e.id)}"]`),e);if(t)return t}return j(e.closest(`label`),e)||M(e)||void 0}function k(e){if(!(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement))return!1;if(e instanceof HTMLInputElement&&e.type===`password`)return!0;let t=(e.getAttribute(`autocomplete`)||``).toLowerCase();if(t.includes(`password`)||t.includes(`cc-`)||t.includes(`one-time`))return!0;let n=`${e.name} ${e.id} ${e.className}`.toLowerCase();return/password|passwd|secret|ssn|credit|card.?number/.test(n)}function A(e,t){if(e instanceof HTMLElement){let t=e.getAttribute(`aria-label`)?.trim();if(t)return N(t)}if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement){if(e.id){let n=j(document.querySelector(`label[for="${F(e.id)}"]`),e);if(n&&t!==`radio`||n&&t===`checkbox`)return n}let n=j(e.closest(`label`),e);if(n&&t===`checkbox`||n&&t!==`radio`)return n;if(t===`radio`){let t=e.closest(`fieldset`)?.querySelector(`legend`);if(t?.textContent?.trim())return N(t.textContent);let n=e.getAttribute(`aria-labelledby`);if(n){let e=document.getElementById(n);if(e?.textContent?.trim())return N(e.textContent)}if(e instanceof HTMLInputElement&&e.name)return N(e.name.replace(/[_-]+/g,` `))}if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){if(e.placeholder?.trim())return N(e.placeholder);let t=e.getAttribute(`title`)?.trim();if(t)return N(t)}if(e.name)return N(e.name.replace(/[_-]+/g,` `))}if(e instanceof HTMLButtonElement||e instanceof HTMLInputElement){let t=e.value?.trim();if(t&&[`button`,`submit`,`reset`].includes(e.type||`button`))return N(t)}if(e instanceof HTMLAnchorElement)return N(e.innerText||e.textContent||``)||e.href||`link`;if(e instanceof HTMLFormElement){let t=e.getAttribute(`name`)?.trim()||e.getAttribute(`aria-label`)?.trim();return t?N(t):e.id?N(e.id.replace(/[_-]+/g,` `)):`form`}if(e instanceof HTMLElement){let t=N(e.innerText||e.textContent||``);if(t)return t.slice(0,80)}return e.tagName.toLowerCase()}function j(e,t){if(!e)return null;let n=e.cloneNode(!0);n.querySelectorAll(`input, select, textarea, button`).forEach(e=>e.remove());let r=N(n.textContent||``);return r?r.slice(0,80):null}function M(e){let t=e.parentElement;if(!t)return null;let n=N(t.innerText||t.textContent||``);return n?n.slice(0,80):null}function N(e){return e.replace(/\s+/g,` `).trim()}function P(e){if(e.id)return`#${F(e.id)}`;let t=[],n=e;for(;n&&t.length<4;){let e=n.tagName.toLowerCase();n.classList.length&&(e+=`.`+Array.from(n.classList).slice(0,2).map(F).join(`.`)),t.unshift(e),n=n.parentElement}return t.join(` > `)}function F(e){return typeof CSS<`u`&&CSS.escape?CSS.escape(e):e.replace(/[^a-zA-Z0-9_-]/g,`\\$&`)}function I(){if(document.getElementById(_))return;let e=document.createElement(`style`);e.id=_,e.textContent=`
    #${g} {
      all: initial;
      position: fixed;
      z-index: 2147483646;
      right: 16px;
      bottom: 16px;
      width: 340px;
      font-family: "Segoe UI", "IBM Plex Sans", sans-serif;
      color: #1a2332;
    }
    #${g} * { box-sizing: border-box; font-family: inherit; }
    #${g} .rs-bar {
      background: rgba(255,255,255,0.97);
      border: 1px solid #d7dee7;
      border-radius: 14px;
      box-shadow: 0 12px 40px rgba(26,35,50,0.18);
      padding: 12px;
      backdrop-filter: blur(8px);
    }
    #${g} .rs-top {
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
    }
    #${g} .rs-brand {
      display: flex; align-items: center; gap: 8px; font-size: 13px;
    }
    #${g} .rs-dot {
      width: 8px; height: 8px; border-radius: 50%; background: #0f6e56;
      box-shadow: 0 0 0 4px rgba(15,110,86,0.15);
    }
    #${g} .rs-dot.paused { background: #b45309; box-shadow: 0 0 0 4px rgba(180,83,9,0.15); }
    #${g} .rs-status { color: #5c6b7a; font-size: 12px; }
    #${g} .rs-count { display: flex; flex-direction: column; align-items: flex-end; line-height: 1.1; }
    #${g} .rs-count-num { font-size: 22px; font-weight: 700; color: #0f6e56; letter-spacing: -0.03em; }
    #${g} .rs-count-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.08em; color: #5c6b7a; }
    #${g} .rs-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
    #${g} .rs-actions-3 { grid-template-columns: 1fr 1fr 1fr; }
    #${g} button {
      border: 1px solid #d7dee7; background: #fff; border-radius: 10px;
      padding: 8px 6px; font-size: 11px; font-weight: 600; cursor: pointer; color: #1a2332;
    }
    #${g} button.rs-stop { background: #0f6e56; border-color: #0f6e56; color: #fff; }
    #${g} .rs-shots {
      margin-top: 8px; font-size: 11px; color: #0f6e56; font-weight: 600;
    }
    #${g} .rs-feed {
      margin-top: 10px; max-height: 220px; overflow: auto;
      display: flex; flex-direction: column; gap: 6px;
    }
    #${g} .rs-empty {
      font-size: 12px; color: #5c6b7a; padding: 8px; background: #f3f6f9; border-radius: 8px;
    }
    #${g} .rs-event {
      font-size: 11px; padding: 8px; border-radius: 8px; background: #e6f4ef;
      animation: rs-pop 180ms ease-out;
    }
    #${g} .rs-event-head { display: flex; gap: 6px; align-items: center; margin-bottom: 4px; }
    #${g} .rs-event-order { font-weight: 700; color: #0f6e56; }
    #${g} .rs-event-type {
      text-transform: uppercase; letter-spacing: 0.04em; color: #5c6b7a; font-size: 10px;
    }
    #${g} .rs-shot-tag {
      margin-left: auto; font-size: 9px; text-transform: uppercase; letter-spacing: 0.06em;
      background: #ffe4e6; color: #be123c; padding: 2px 6px; border-radius: 999px; font-weight: 700;
    }
    #${g} .rs-event-text { color: #1a2332; line-height: 1.35; }
    #${g} .rs-event-text strong { font-weight: 700; color: #0b4f3d; }
    #${g} .rs-expected {
      margin-top: 4px; padding-top: 4px; border-top: 1px dashed #b7d7cb;
      color: #3d4f5f; font-size: 10.5px; line-height: 1.35;
    }
    #${g} .rs-expected span { font-weight: 700; color: #5c6b7a; margin-right: 4px; }
    #${g} .rs-expected strong { font-weight: 700; color: #0b4f3d; }
    @keyframes rs-pop {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }

    #testbuddy-annotate-overlay {
      all: initial;
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      background: rgba(15, 23, 32, 0.72);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
      font-family: "Segoe UI", "IBM Plex Sans", sans-serif;
      color: #1a2332;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay * { box-sizing: border-box; font-family: inherit; }
    #testbuddy-annotate-overlay .tb-ann-panel {
      width: min(980px, 100%);
      background: #fff;
      border-radius: 16px;
      padding: 14px;
      box-shadow: 0 24px 64px rgba(0,0,0,0.35);
      display: flex;
      flex-direction: column;
      gap: 10px;
      max-height: calc(100vh - 32px);
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-head {
      display: flex; flex-direction: column; gap: 2px;
    }
    #testbuddy-annotate-overlay .tb-ann-head strong { font-size: 16px; }
    #testbuddy-annotate-overlay .tb-ann-head span { font-size: 12px; color: #5c6b7a; }
    #testbuddy-annotate-overlay .tb-ann-stage {
      overflow: auto; background: #0f1720; border-radius: 12px;
      display: flex; justify-content: center; align-items: center; padding: 8px;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-canvas {
      cursor: crosshair;
      max-width: 100%;
      border-radius: 4px;
      touch-action: none;
      pointer-events: auto !important;
      user-select: none;
      display: block;
    }
    #testbuddy-annotate-overlay .tb-ann-status {
      min-height: 18px;
      font-size: 12px;
      font-weight: 600;
      color: #5c6b7a;
    }
    #testbuddy-annotate-overlay .tb-ann-status[data-kind="ok"] { color: #0f6e56; }
    #testbuddy-annotate-overlay .tb-ann-status[data-kind="error"] { color: #be123c; }
    #testbuddy-annotate-overlay .tb-ann-label {
      display: flex; flex-direction: column; gap: 6px;
      font-size: 12px; font-weight: 600; color: #3d4f5f;
    }
    #testbuddy-annotate-overlay .tb-ann-overview {
      width: 100%; resize: vertical; min-height: 56px;
      border: 1px solid #d7dee7; border-radius: 10px; padding: 10px;
      font-size: 13px; font-weight: 400; color: #1a2332;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-actions {
      display: flex; gap: 8px; justify-content: flex-end; flex-wrap: wrap;
    }
    #testbuddy-annotate-overlay .tb-ann-actions button {
      border: 1px solid #d7dee7; background: #fff; border-radius: 10px;
      padding: 9px 12px; font-size: 12px; font-weight: 600; cursor: pointer;
      pointer-events: auto;
    }
    #testbuddy-annotate-overlay .tb-ann-primary {
      background: #0f6e56 !important; border-color: #0f6e56 !important; color: #fff !important;
    }
    #testbuddy-annotate-overlay .tb-ann-hint {
      font-size: 11px; color: #5c6b7a;
    }
  `,document.documentElement.appendChild(e)}})();